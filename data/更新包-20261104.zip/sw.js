/* 备考站 Service Worker
   策略：导航与题库走「网络优先」（更新立刻可见），静态资源走「缓存优先」。
   改动内容后请把 VER 加一，旧缓存会自动清理。 */
const VER = 'yek-v2';
const SHELL = [
  './', './index.html', './manifest.json', './manifest.js', './js/core.js',
  './data/kp.js', './data/00-plan.js', './data/quotes.js', './data/detail.js', './data/qdetail.js',
  './data/01-socio.js', './data/02-epi.js', './data/03-stat.js', './data/04-prev.js',
  './icon-192.png', './icon-512.png', './apple-touch-icon.png'
];

self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(caches.open(VER).then(c => c.addAll(SHELL)).catch(() => { }));
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== VER).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

// 网络优先：先取最新，失败回落缓存
async function netFirst(req, key) {
  try {
    const fresh = await fetch(req, { cache: 'no-store' });
    if (fresh && fresh.ok) {
      const c = await caches.open(VER);
      c.put(key || req, fresh.clone()).catch(() => { });
    }
    return fresh;
  } catch (err) {
    const c = await caches.open(VER);
    return (await c.match(key || req)) || Response.error();
  }
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  if (req.mode === 'navigate') { e.respondWith(netFirst(req, './index.html')); return; }

  // 题库与讲解：网络优先，保证更新即时生效
  if (url.pathname.indexOf('/data/') >= 0) { e.respondWith(netFirst(req)); return; }

  // 其余静态资源：缓存优先，后台更新
  e.respondWith((async () => {
    const c = await caches.open(VER);
    const hit = await c.match(req);
    if (hit) {
      fetch(req).then(r => { if (r && r.ok) c.put(req, r.clone()).catch(() => { }); }).catch(() => { });
      return hit;
    }
    try {
      const r = await fetch(req);
      if (r && r.ok) c.put(req, r.clone()).catch(() => { });
      return r;
    } catch (err) { return Response.error(); }
  })());
});
